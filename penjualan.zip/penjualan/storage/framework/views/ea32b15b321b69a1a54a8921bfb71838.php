<?php
    $nama = "Budi";
    $nilai = 60;
?>



    <?php if($nilai >= 60): ?>
        <?php
            $ket = 'lulus'
        ?>
        
    <?php else: ?>
        <?php
            $ket = 'Tidak lulus';
        ?>  
    <?php endif; ?>

    Siswa yang bernama <?php echo e($nama); ?>

    <br>Dengan Nilai <?php echo e($nilai); ?>

    <br>Dengan variable <?php echo e($ket); ?><?php /**PATH C:\xampp\htdocs\prakweb2\Laravel\penjualan\resources\views/nilai.blade.php ENDPATH**/ ?>