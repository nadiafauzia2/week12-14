

<?php $__env->startSection('content'); ?>

    <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex align-items-center">
    <div class="container d-flex flex-column align-items-center" data-aos="zoom-in" data-aos-delay="100">
      <h1>Nadia Fauzia</h1>
      <h2>I am a flower shop owner</h2>
      <a href="<?php echo e(url('frontend/about')); ?>" class="btn-about">About Me</a>
    </div>
  </section><!-- End Hero -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\prakweb2\Laravel\penjualan\resources\views/frontend/dashboard.blade.php ENDPATH**/ ?>