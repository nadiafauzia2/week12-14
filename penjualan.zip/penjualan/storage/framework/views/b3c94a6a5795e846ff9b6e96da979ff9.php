
<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <h1 class="mt-4">Tables</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="index.html">Dashboard</a></li>
        <li class="breadcrumb-item active">Kategori</li>
    </ol>
    
    <div class="card mb-4 table-responsive">
        <div class="card-header">
            <a href="<?php echo e(url('admin/kategori/create')); ?>" class="btn btn-primary">Tambah data</a>
        </div>
        <div class="card mb-4 table-responsive">
            <div class="card-header">
                <i class="fas fa-table me-1"></i>
                Data Kategori
            </div>
            <div class="card-body">
                <table id="datatablesSimple">
                    <thead>
                        <tr>
                              <th>Nama</th>
                            
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 1;
                        ?>
                        <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                        <tr>
                        <td><?php echo e($kat->nama); ?></td>

                            <td><a href="<?php echo e(url('admin/kategori/edit/'. $kat->id)); ?>" class="btn btn-success">Edit</a></td>
                            <td><a href="<?php echo e(url('admin/kategori/delete/'. $kat->id)); ?>" class="btn btn-danger">Delete</a></td>
                        </tr>
                        <tr>
                        <?php
                        $no++
                        ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\prakweb2\Laravel\penjualan\resources\views/admin/kategori/kategori.blade.php ENDPATH**/ ?>