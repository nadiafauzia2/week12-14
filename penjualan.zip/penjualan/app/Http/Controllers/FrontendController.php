<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class FrontendController extends Controller
{
    public function index(){
        return view('frontend/dashboard');
    }
    public function about(){
        return view('frontend/about/about');
    }
    public function resume(){
        return view('frontend/resume');
    }
    public function services(){
        return view('frontend/services');
    }
    public function contact(){
        return view('frontend/contact');
    }
    public function portfolio(){
        return view('frontend/portfolio');
    }
}
