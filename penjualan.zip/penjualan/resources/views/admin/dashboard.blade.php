@extends('admin.layout.app')
{{-- ^orang tua atau parent --}}
@section('content')
{{-- ^nama dari halaman atau anak --}}
    ini adalah halaman Dashboard
@endsection