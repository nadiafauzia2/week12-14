@extends('admin.layout.app')
@selection('content')
    <h1>Akses di tolak,karena role anda pelanggan.!!!</h1>
@endsection