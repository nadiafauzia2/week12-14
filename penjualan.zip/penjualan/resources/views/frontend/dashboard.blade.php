@extends('frontend.layout.app')
{{-- ^orang tua atau parent --}}
@section('content')
{{-- ^nama dari halaman atau anak --}}
    <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex align-items-center">
    <div class="container d-flex flex-column align-items-center" data-aos="zoom-in" data-aos-delay="100">
      <h1>Nadia Fauzia</h1>
      <h2>I am a flower shop owner</h2>
      <a href="{{url('frontend/about')}}" class="btn-about">About Me</a>
    </div>
  </section><!-- End Hero -->
@endsection